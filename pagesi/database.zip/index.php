<?php
// Redirect to the new responsive home page
header("Location: pages/home.php");
exit();
?>
